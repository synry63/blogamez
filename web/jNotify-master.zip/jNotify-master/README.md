# Readme

Full documentation on [MyJqueryPlugins](http://www.myjqueryplugins.com/jNotify)

Demonstration on [jNotify demonstration page](http://www.myjqueryplugins.com/jNotify/demo)